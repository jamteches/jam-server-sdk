# Jam Server Flutter SDK

A complete Flutter SDK for [Jam Server](https://github.com/jamteches/jam-server) - Firebase-like backend with powerful features.

## 🚀 Features

- **Authentication** - JWT login, registration, password reset
- **Project Auth** - Multi-tenant user authentication per project
- **Database** - NoSQL document storage with real-time updates
- **Storage** - File upload/download with chunked upload support
- **AI** - Chat, knowledge base, RAG (Retrieval Augmented Generation)
- **Transcription** - Audio/video transcription with AI
- **Real-time** - WebSocket-based live updates
- **Admin** - Backup, logs, metrics management

## 📦 Installation

Add to your `pubspec.yaml`:

```yaml
dependencies:
  jam_server_sdk:
    path: ./sdk/flutter  # or use git URL
```

## 🔧 Quick Start

### Basic Setup

```dart
import 'package:jam_server_sdk/jam.dart';

void main() async {
  // Initialize with base URL
  final jam = Jam('https://api.jamteches.com');
  
  // Login as admin/user
  await jam.auth.login(username: 'john', password: 'password');
  
  // Set project context (required for most operations)
  jam.setProject('my-project-id');
  
  // Now use the SDK!
}
```

### Using API Key (Recommended for Apps)

```dart
// Initialize with API Key - auto project context!
final jam = Jam(
  'https://api.jamteches.com',
  apiKey: 'jam_pk_91b12f62fa9db98afd6fcabfbfee79776d29c01a825e1cb5f0f1a48754a0f2a2',
);

// No need to set project - it's automatic from API Key!
final docs = await jam.db.collection('users').list();
```

## 📚 Database Operations

### List Documents

```dart
// List all documents in a collection
final users = await jam.db.collection('users').list();

// With pagination
final users = await jam.db.collection('users').list(
  page: 1,
  limit: 20,
);

// With filters
final adults = await jam.db.collection('users').list(
  filters: {'age_gte': 18},
);
```

### Create Document

```dart
final newUser = await jam.db.collection('users').add({
  'name': 'John Doe',
  'email': 'john@example.com',
  'age': 30,
});

print('Created user: ${newUser['id']}');
```

### Get Single Document

```dart
final user = await jam.db.collection('users').get('document-id');
```

### Update Document

```dart
await jam.db.collection('users').update('document-id', {
  'name': 'John Updated',
  'age': 31,
});
```

### Delete Document

```dart
await jam.db.collection('users').delete('document-id');
```

## 📁 Storage Operations

### Upload File

```dart
// From file path
final result = await jam.storage.upload('/path/to/file.pdf');
print('Uploaded: ${result['filename']}');

// From bytes
final result = await jam.storage.uploadBytes(
  bytes: fileBytes,
  filename: 'document.pdf',
);
```

### Chunked Upload (Large Files)

```dart
// For files > 100MB
final result = await jam.chunkedUpload.upload(
  filePath: '/path/to/large-video.mp4',
  projectId: 'my-project',
  onProgress: (progress) {
    print('Upload: ${progress.percentage.toStringAsFixed(1)}%');
  },
);
```

### List Files

```dart
final files = await jam.storage.listFiles();
for (final file in files) {
  print('${file['original_name']} - ${file['size']} bytes');
}
```

### Download File

```dart
final bytes = await jam.storage.downloadBytes('filename.pdf');
```

### Delete File

```dart
await jam.storage.delete('filename.pdf');
```

## 👥 Project User Authentication

For multi-tenant apps where each project has its own users:

### Register Project User

```dart
final auth = jam.projectAuth('my-project-id');

final result = await auth.register(
  email: 'user@example.com',
  password: 'securepassword123',
);

print('User ID: ${result.user.id}');
print('Token: ${result.token}');
```

### Login Project User

```dart
final result = await auth.login(
  email: 'user@example.com',
  password: 'securepassword123',
);

print('Welcome ${result.user.username}!');
```

### Get Current User

```dart
final user = await auth.me();
print('Logged in as: ${user.email}');
```

### Update Profile

```dart
await auth.updateProfile(
  username: 'newusername',
  metadata: {'theme': 'dark'},
);
```

### Change Password

```dart
await auth.changePassword(
  currentPassword: 'oldpassword',
  newPassword: 'newpassword',
);
```

### Logout

```dart
await auth.logout();  // Revokes token
```

### Forgot Password (UI Flow)

For best UX, open the web page in a browser:

```dart
import 'package:url_launcher/url_launcher.dart';

// Get the forgot password URL
final url = auth.forgotPasswordUrl;
// Opens: https://api.jamteches.com/project-forgot-password.html?project_id=xxx

// Launch in browser
await launchUrl(Uri.parse(url));
```

### Forgot Password (API Flow)

Handle the entire flow in your app:

```dart
// Step 1: Request OTP
await auth.forgotPassword('user@example.com');
// User receives OTP via email

// Step 2: Reset password with OTP
await auth.resetPassword(
  email: 'user@example.com',
  otp: '123456',  // From email
  newPassword: 'newSecurePassword123',
);
```

### Password Reset URLs

```dart
// Get URLs for web pages
final forgotUrl = auth.forgotPasswordUrl;
// https://api.jamteches.com/project-forgot-password.html?project_id=xxx

final resetUrl = auth.resetPasswordUrl;
// https://api.jamteches.com/project-reset-password.html?project_id=xxx

// API base URL
final apiBase = auth.authBaseUrl;
// https://api.jamteches.com/api/projects/xxx/auth
```

## ⚙️ Project Settings

```dart
final settings = jam.projectSettings('my-project-id');

// Get settings
final currentSettings = await settings.get();
print('Max users: ${currentSettings.maxUsers}');

// Update settings
await settings.update(ProjectSettingsUpdate(
  allowRegistration: true,
  maxUsers: 500,
  userCanDelete: false,
));

// Quick toggles
await settings.disableRegistration();
await settings.requireEmailVerification();
await settings.setAllowedDomains(['@company.com']);
```

## 🤖 AI & Chat

### Chat with AI

```dart
final response = await jam.ai.chat(
  projectId: 'my-project',
  message: 'What are the key features of your product?',
);

print('AI: ${response['answer']}');
```

### With Context/History

```dart
final response = await jam.ai.chat(
  projectId: 'my-project',
  message: 'Tell me more',
  history: [
    {'role': 'user', 'content': 'What is Jam Server?'},
    {'role': 'assistant', 'content': 'Jam Server is...'},
  ],
);
```

## 🎙️ Transcription

### Basic Transcription

```dart
// Transcribe audio/video
final result = await jam.transcription.transcribe('/path/to/audio.mp3');

for (final segment in result.segments) {
  print('[${segment.start}s - ${segment.end}s] ${segment.text}');
}

// Get full text
print('Full transcript: ${result.text}');
```

### Async Transcription (Large Files)

```dart
// Submit job
final job = await jam.transcription.transcribeAsync(
  '/path/to/video.mp4',
  projectId: 'my-project',
  language: 'th',
);

// Wait for completion
final result = await jam.transcription.waitForCompletion(
  job['job_id'],
  onProgress: (progress) => print('Progress: $progress%'),
);

print('Done! ${result.segments.length} segments');
```

### Speaker Diarization (Who Said What)

```dart
// Transcribe with speaker identification
final job = await jam.transcription.transcribeAsync(
  '/path/to/meeting.mp4',
  projectId: 'my-project',
  language: 'th',
  diarize: true,  // Enable speaker diarization
);

// Wait for completion
final result = await jam.transcription.waitForCompletion(job['job_id']);

// Check detected speakers
final speakers = result.segments
  .map((s) => s.speaker)
  .where((s) => s != null)
  .toSet();

print('Detected speakers: $speakers');
// Output: {SPEAKER_00, SPEAKER_01, SPEAKER_02}

// Get speaker statistics
final stats = await jam.transcription.getSpeakerStats(job['job_id']);
print('Speaker stats: $stats');
// Output: {SPEAKER_00: 45, SPEAKER_01: 23, SPEAKER_02: 12}
```

### Map Speaker Names

```dart
// After diarization, map speaker IDs to real names
await jam.transcription.updateSpeakerNames(
  job['job_id'],
  {
    'SPEAKER_00': 'CEO',
    'SPEAKER_01': 'Manager',
    'SPEAKER_02': 'Employee',
  },
);

// Get updated result with real names
final updated = await jam.transcription.getJob(job['job_id']);

for (final segment in updated.segments) {
  print('[${segment.start}s] ${segment.speaker}: ${segment.text}');
}
// Output:
// [0.0s] CEO: Let's discuss the quarterly results
// [5.2s] Manager: Sales increased by 15% this quarter
// [12.3s] Employee: I can prepare the detailed report
```

### Complete Diarization Workflow

```dart
// 1. Transcribe with diarization
final job = await jam.transcription.transcribeAsync(
  audioFile,
  projectId: 'my-project',
  diarize: true,
);

// 2. Wait for completion
final result = await jam.transcription.waitForCompletion(job['job_id']);

// 3. Get speaker stats (to decide who is who)
final stats = await jam.transcription.getSpeakerStats(job['job_id']);
final entries = stats.entries.toList()
  ..sort((a, b) => b.value.compareTo(a.value));

print('Main speaker: ${entries.first.key} spoke ${entries.first.value} times');

// 4. Show UI to let user map names
// (In your Flutter app, show dialog/form)

// 5. Update speaker names
await jam.transcription.updateSpeakerNames(
  job['job_id'],
  speakerMapping, // From user input
);

// 6. Display final transcript with names
final final updated = await jam.transcription.getJob(job['job_id']);
// Now segments have real names instead of SPEAKER_XX
```

## 🔴 Real-time Updates

```dart
// Connect to WebSocket
jam.realtime.connect();

// Subscribe to collection
jam.realtime.subscribe('messages');

// Listen for events
jam.realtime.stream.listen((event) {
  if (event.type == RealtimeEventType.create) {
    print('New message: ${event.data}');
  } else if (event.type == RealtimeEventType.update) {
    print('Message updated: ${event.documentId}');
  } else if (event.type == RealtimeEventType.delete) {
    print('Message deleted: ${event.documentId}');
  }
});

// Disconnect when done
jam.realtime.disconnect();
```

## 🔧 Admin Operations

```dart
// Backup database
await jam.admin.createBackup();

// List backups
final backups = await jam.admin.listBackups();

// Get server metrics
final metrics = await jam.admin.getMetrics();
print('Total requests: ${metrics['requests']}');
```

## 🔐 Authentication Methods

### 1. JWT Token (Server Admin)

```dart
final jam = Jam('https://api.jamteches.com');
await jam.auth.login(username: 'admin', password: 'password');
jam.setProject('project-id');
```

### 2. API Key (Recommended for Apps)

```dart
final jam = Jam(
  'https://api.jamteches.com',
  apiKey: 'jam_pk_xxx',
);
// Project is automatic from API Key!
```

### 3. Project User Token

```dart
final jam = Jam('https://api.jamteches.com');
final auth = jam.projectAuth('project-id');
await auth.login(email: 'user@test.com', password: 'pass');
// Token is stored internally
```

## ❌ Error Handling

```dart
try {
  await jam.db.collection('users').get('invalid-id');
} on JamException catch (e) {
  print('Error: ${e.message}');
  print('Status: ${e.statusCode}');
  
  if (e.isUnauthorized) {
    // Redirect to login
  } else if (e.isNotFound) {
    // Show not found message
  } else if (e.isServerError) {
    // Show server error
  }
}
```

## 📱 Full App Example

```dart
import 'package:jam_server_sdk/jam.dart';

class MyApp {
  late final Jam jam;
  
  Future<void> initialize() async {
    // Use API Key for client apps
    jam = Jam(
      'https://api.jamteches.com',
      apiKey: 'jam_pk_xxx',
    );
  }
  
  Future<List<Map<String, dynamic>>> getTasks() async {
    return await jam.db.collection('tasks').list();
  }
  
  Future<void> addTask(String title) async {
    await jam.db.collection('tasks').add({
      'title': title,
      'completed': false,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
  
  Future<void> uploadFile(String path) async {
    await jam.storage.upload(path);
  }
  
  void dispose() {
    jam.dispose();
  }
}
```

## 📋 API Reference

### Jam Class

| Method | Description |
|--------|-------------|
| `setProject(projectId)` | Set default project context |
| `setToken(token)` | Set JWT token manually |
| `dispose()` | Clean up resources |

### Services

| Service | Description |
|---------|-------------|
| `jam.auth` | Server admin authentication |
| `jam.db` | Database operations |
| `jam.storage` | File storage |
| `jam.projects` | Project management |
| `jam.ai` | AI/Chat operations |
| `jam.transcription` | Audio/video transcription |
| `jam.realtime` | WebSocket real-time updates |
| `jam.admin` | Admin operations |
| `jam.projectAuth(projectId)` | Project-specific user auth |
| `jam.projectSettings(projectId)` | Project settings management |

## 🤝 Contributing

Contributions are welcome! Please read our contributing guidelines.

## 📄 License

MIT License - See LICENSE file for details.

---

Made with ❤️ by JamTeches
